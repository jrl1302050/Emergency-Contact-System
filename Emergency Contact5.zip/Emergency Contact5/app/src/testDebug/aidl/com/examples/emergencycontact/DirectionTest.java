package com.examples.emergencycontact;

import static org.junit.Assert.*;

/**
 * Created by JAHURUL ISLAM on 11/19/2017.
 */
public class DirectionTest {

}